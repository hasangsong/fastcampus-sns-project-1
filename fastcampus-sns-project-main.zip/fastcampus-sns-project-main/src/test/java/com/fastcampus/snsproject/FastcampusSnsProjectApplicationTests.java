package com.fastcampus.snsproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastcampusSnsProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
