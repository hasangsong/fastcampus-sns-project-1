package com.fastcampus.snsproject.model;

public enum UserRole {

    ADMIN,
    USER
}
